<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/admin', function () {
    return view('admin_login');
});

Route::get('/employee', function () {
    return view('emp_login');
});

Route::get('/sales', function () {
    return view('sales_login');
});

/*Login Actions Started here*/
Route::post('/hr_login', 'AdminController@hr_login');
Route::get('/design_home', 'AdminController@admin_index');
Route::get('/employee_list', 'AdminController@employee_list');
Route::get('/logout', 'AdminController@logout');

/*Add Employee Details*/
Route::get('/add_employee', 'EmployeeController@employee_add');
Route::post('/save_details', 'EmployeeController@save_employee');
Route::get('/show_employee_list', 'EmployeeController@show_employee_list');
Route::get('/employee_history', 'EmployeeController@show_employee_history');

/*Edit Employee Details*/
Route::get('/edit_employee/{id}', 'EmployeeController@employee_edit');
Route::post('/update_employee', 'EmployeeController@update_employee');
Route::get('/delete_employee/{id}', 'EmployeeController@delete_employee');

/*Add Department Category*/
Route::get('/add_department', 'DepartmentController@index');
Route::post('/save_department', 'DepartmentController@save');

/*Route for Calendar events*/
Route::get('/add_events', 'CalendarController@events');
Route::post('/save_event', 'CalendarController@save');