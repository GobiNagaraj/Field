<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeehistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employeehistories', function(Blueprint $table){
            $table -> increments('id');
            $table -> string('emp_fname');
            $table -> string('emp_lname');
            $table -> date('emp_dob');
            $table -> string('emp_age');
            $table -> string('emp_mail');
            $table -> bigInteger('emp_number1');
            $table -> bigInteger('emp_number2');
            $table -> date('emp_doj');
            $table -> string('emp_address');
            $table -> string('emp_status');
            $table -> string('emp_company');
            $table -> string('emp_experience');
            $table -> string('emp_resume');
            $table -> string('emp_department');
            $table -> string('emp_image');
            $table -> string('company_mail');
            $table -> string('emp_id');
            $table -> string('emp_password');
            $table -> timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employeehistories');
    }
}
