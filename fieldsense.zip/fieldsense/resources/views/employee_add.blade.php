@include('styles.app-css')

<style type="text/css">
  .form-control
  {
    width: 70%;
  }
</style>

<script type="text/javascript">
  /*script for Age Calculation*/
  function getAge(){
    var dob = document.getElementById('date').value;
    dob = new Date(dob);
    var today = new Date();
    var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
    document.getElementById('emp_age').value=age;
  }

  /*script for experience and fresher button*/
  function show1(){
  document.getElementById('div1').style.display ='none';
  }
  function show2(){
  document.getElementById('div1').style.display = 'block';
  }
</script>

<body>
  <section id="container" >
      <!--header start-->
        @include('emp_layouts.headerbar');
      <!--header end-->
      <!--sidebar start-->
        @include('emp_layouts.sidebar');
      <!--sidebar end-->
      <!--main content start-->
      <section id="main-content">
        <section class="wrapper">
            <h1>Add Employee Details</h1><br>
      <!-- Add Employee Details -->
<form method="POST" action="/save_details" enctype="multipart/form-data">
      {{csrf_field()}}
        <table class="table table-bordered">
            <tr>
                <td><label>Name</label></td>
                <td><input type="text" name="emp_fname" class="form-control" placeholder="Enter First Name" ></td>
                <td><input type="text" name="emp_lname" class="form-control" placeholder="Enter Last Name" ></td>
            </tr>
            <tr>
                <td><label>Data of Birth</label></td>
                <td><input type="date" value="" id="date" name="emp_dob" class="form-control" onblur="getAge();" /></td>
            </tr>
            <tr>
                <td><label>Age</label></td>
                <td><input type="text" id="emp_age" name="emp_age" value="" class="form-control" placeholder="Enter Age" ></td>
                <td><input type="email" name="emp_mail" class="form-control" placeholder="Enter Email" ></td>
            </tr>
            <tr>
                <td><label>Contact Number</label></td>
                <td><input type="text" name="emp_number1" class="form-control" placeholder="Enter Contact 1" ></td>
                <td><input type="text" name="emp_number2" class="form-control" placeholder="Enter Contact 2" ></td>
            </tr>
            <tr>
                <td><label>Data of Joining</label></td>
                <td><input type="date" name="emp_doj" class="form-control" placeholder="Select Data of Joining" ></td>
            </tr>
            <tr>
                <td><label>Address</label></td>
                <td><textarea cols="10" rows="6" name="emp_address" class="form-control" ></textarea></td>
            </tr>
            <tr>
                <td><label>Employee Status</label></td>
                <td>
                  <input type="radio" name="emp_status" value="fresher" onclick="show1();" />Fresher
                  <input type="radio" name="emp_status" value="experience" onclick="show2();"  checked/>Experience
                </td>
                <td>
                  <div id="div1">
                    <input type="text" name="emp_company" class="form-control" placeholder="Enter Company Name"><br>
                    <input type="text" name="emp_experience" class="form-control" placeholder="Enter Exp Years" id="company">
                  </div>
                </td>
            </tr>
            <tr>
              <td><label>Upload Resume</label></td>
                <td><input type="file" name="emp_resume" class="form-control" id="emp_resume" accept="application/pdf" title="Choose File"></td>
            </tr>
            <tr>
              <td><label>Allocate Department</label></td>
                <td>
                <select name="emp_department" class="form-control">
                  <option value="none">--- Select a category ---</option>
                    @foreach($dept as $var)
                            <option value="{{ $var['id'] }}">{{ $var['department'] }}</option>
                    @endforeach
                </select>
                </td>
            </tr>
            <tr>
                <td><label>Employee Image</label></td>
                <td><input type="file" class="form-control" name="emp_image" ></td>
            </tr>
            <tr>
                <td><label>Company Mail</label></td>
                <td><input type="email" name="company_mail" class="form-control" placeholder="Enter Company Mail id" ></td>
            </tr>
            <tr>
                <td><label>Employee Id</label></td>
                <td><input type="text" name="emp_id" class="form-control" placeholder="Employee Id" ></td>
                <td><input type="password" name="emp_password" class="form-control" placeholder="Employee Password" ></td>
            </tr>
            <tr>
                <td><input type="submit" name="submit" class="btn btn-success" value="Add Employee"></td>
            </tr>

        </table>
    </form>

          </section>
      </section>
      <!--main content end-->

      <!-- Right Slidebar start -->
      <div class="sb-slidebar sb-right sb-style-overlay">
          <h5 class="side-title">Online Customers</h5>
          <ul class="quick-chat-list">
              <li class="online">
                  <div class="media">
                      <a href="#" class="pull-left media-thumb">
                          <img alt="" src="img/chat-avatar2.jpg" class="media-object">
                      </a>
                      <div class="media-body">
                          <strong>John Doe</strong>
                          <small>Dream Land, AU</small>
                      </div>
                  </div><!-- media -->
              </li>
              <li class="online">
                  <div class="media">
                      <a href="#" class="pull-left media-thumb">
                          <img alt="" src="img/chat-avatar.jpg" class="media-object">
                      </a>
                      <div class="media-body">
                          <div class="media-status">
                              <span class=" badge bg-important">3</span>
                          </div>
                          <strong>Jonathan Smith</strong>
                          <small>United States</small>
                      </div>
                  </div><!-- media -->
              </li>

              <li class="online">
                  <div class="media">
                      <a href="#" class="pull-left media-thumb">
                          <img alt="" src="img/pro-ac-1.png" class="media-object">
                      </a>
                      <div class="media-body">
                          <div class="media-status">
                              <span class=" badge bg-success">5</span>
                          </div>
                          <strong>Jane Doe</strong>
                          <small>ABC, USA</small>
                      </div>
                  </div><!-- media -->
              </li>
              <li class="online">
                  <div class="media">
                      <a href="#" class="pull-left media-thumb">
                          <img alt="" src="img/avatar1.jpg" class="media-object">
                      </a>
                      <div class="media-body">
                          <strong>Anjelina Joli</strong>
                          <small>Fockland, UK</small>
                      </div>
                  </div><!-- media -->
              </li>
              <li class="online">
                  <div class="media">
                      <a href="#" class="pull-left media-thumb">
                          <img alt="" src="img/mail-avatar.jpg" class="media-object">
                      </a>
                      <div class="media-body">
                          <div class="media-status">
                              <span class=" badge bg-warning">7</span>
                          </div>
                          <strong>Mr Tasi</strong>
                          <small>Dream Land, USA</small>
                      </div>
                  </div><!-- media -->
              </li>
          </ul>
          <h5 class="side-title"> pending Task</h5>
          <ul class="p-task tasks-bar">
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Dashboard v1.3</div>
                          <div class="percent">40%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 40%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="40" role="progressbar" class="progress-bar progress-bar-success">
                              <span class="sr-only">40% Complete (success)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Database Update</div>
                          <div class="percent">60%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 60%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="60" role="progressbar" class="progress-bar progress-bar-warning">
                              <span class="sr-only">60% Complete (warning)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Iphone Development</div>
                          <div class="percent">87%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 87%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="20" role="progressbar" class="progress-bar progress-bar-info">
                              <span class="sr-only">87% Complete</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Mobile App</div>
                          <div class="percent">33%</div>
                      </div>
                      <div class="progress progress-striped">
                          <div style="width: 33%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="80" role="progressbar" class="progress-bar progress-bar-danger">
                              <span class="sr-only">33% Complete (danger)</span>
                          </div>
                      </div>
                  </a>
              </li>
              <li>
                  <a href="#">
                      <div class="task-info">
                          <div class="desc">Dashboard v1.3</div>
                          <div class="percent">45%</div>
                      </div>
                      <div class="progress progress-striped active">
                          <div style="width: 45%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="45" role="progressbar" class="progress-bar">
                              <span class="sr-only">45% Complete</span>
                          </div>
                      </div>

                  </a>
              </li>
          </ul>
      </div>
      <!-- Right Slidebar end -->

@include('styles.app-script')
</body>