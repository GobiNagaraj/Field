@extends('layouts.app')

@section('content')

<body>

<div class="login_form">
  <setion class="login-wrapper">
    
    <form id="login" method="post" action="#">
      <header class="login-form__header">
          <img src="{{URL::asset('/images/ed.jpg')}}" alt="Edcloud Solution"  />
          <br />
    </header>
      <label for="username">User Name</label>
      <input  required name="login[username]" type="text" autocapitalize="off" autocorrect="off"/>

      <label for="password">Password</label>
      <input class="password" required name="login[password]" type="password" />
      <div class="hide-show">
        <span>Show</span>
      </div>
      <button type="submit">Sign In</button>
    </form>
    
  </section>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
</body>
  @endsection








<!-- @extends('layouts.app')

@section('content')
<div class="perspective-container">
    <div class="login-card">
      <form action="../controller/hr-login-controller.php" method="POST" class="login-form login-form_sing-in">
        <header class="login-form__header">
          <img src="{{URL::asset('/images/ed.jpg')}}" alt="Edcloud Solution"  />
          <br />
        </header>
        <div class="login-form__inputs-container">
        	<input type="email" name="usermail" placeholder="Enter Mail" class="login-form__input login-form__input_required" >
        	<input type="password" name="userpass" placeholder="Enter Password" class="login-form__input login-form__input_required" >
        </div>

        <footer class="login-form__footer">
          <button type="submit" class="login-form__submit"> Sign in now
          </button>
          <div class="checkbox__title"> Need an account? <a href="#" class="login-form__toggle">Sing Up</a>
          </div>
        </footer>
      </form>
    </div>
  </div>
  @endsection -->