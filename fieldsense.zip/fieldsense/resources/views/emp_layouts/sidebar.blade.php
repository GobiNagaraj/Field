<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
                  <li>
                      <a class="active" href="/design_home">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-group"></i>
                          <span>Employees</span>
                      </a>
                      <ul class="sub">
                          <li><a href="/employee_list">Employees List</a></li>
                          <li><a href="/employee_history">Employees History</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-user"></i>
                          <span>Attendance</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="mark_attendance.php">Mark Attendance</a></li>
                          <li><a  href="view_attendance.php">View Attendance</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-book"></i>
                          <span>Department</span>
                      </a>
                      <ul class="sub">
                          <li><a href="/add_department">Add Department</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-trophy"></i>
                          <span>Award</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="award_list.php">Award List</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-money"></i>
                          <span>Expense</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="expense_list.php">Expense List</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-calendar"></i>
                          <span>Calendar</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="/add_events">Show Events</a></li>
                      </ul>
                  </li>
                  
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-paste"></i>
                          <span>Leave Applications</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="leave_applications.php">Leave Details</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-shopping-cart"></i>
                          <span>Pay Slip</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="payslip.php">Pay Slip List</a></li>
                          <li><a href="month_payslip.php">Monthly Slip</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-gears"></i>
                          <span>Settings</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="user_profile.php">My Profile</a></li>
                      </ul>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>