<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employeehistory extends Model
{
    protected $fillabe = ['emp_fname', 'emp_lname' , 'emp_dob', 
    					  'emp_age', 'emp_mail', 'emp_number1',
    					  'emp_number2', 'emp_doj', 'emp_address',
    					  'emp_status', 'emp_company', 'emp_experience',
    					  'emp_resume', 'emp_department', 'emp_image',
    					  'company_mail', 'emp_id', 'emp_password'];
}
