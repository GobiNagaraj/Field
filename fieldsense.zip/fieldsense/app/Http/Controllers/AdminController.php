<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Addemployee;

class AdminController extends Controller
{
    public function hr_login(){
    	return view('admin_panel');
    }

    public function admin_index(){
    	return view('admin_panel');
    }
    public function employee_list(){
    	$value['value'] = Addemployee::all();
        return view('employee_list', $value);
    }
    public function logout(){
        return view('admin_login');
    }
}
