<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Addemployee;
use App\Department;
use App\Employeehistory;

class EmployeeController extends Controller
{
    public function employee_add()
    {
        $dept['dept'] = Department::all();
    	return view('employee_add', $dept);
    }

    public function show_employee_list()
    {
        $value['value'] = Addemployee::all();
        return view('employee_list', $value);
    }

    /*Save Details of Employee in Table*/
    public function save_employee(Request $request)
    {
        $insert = new Addemployee;

        /*$insert->validate($request, [
        'emp_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);*/
        if ($request->hasFile('emp_image')) {
        $image = $request->file('emp_image');
        $name = time().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('emp_images');
        $image->move($destinationPath, $name);
        /*$insert->save();*/

        //return back()->with('success','Image Upload successfully');
        }
    	$insert->emp_fname = $request->emp_fname;
    	$insert->emp_lname = $request->emp_lname;
    	$insert->emp_dob = $request->emp_dob;
    	$insert->emp_age = $request->emp_age;
    	$insert->emp_mail = $request->emp_mail;
    	$insert->emp_number1 = $request->emp_number1;
    	$insert->emp_number2 = $request->emp_number2;
    	$insert->emp_doj = $request->emp_doj;
    	$insert->emp_address = $request->emp_address;
    	$insert->emp_status = $request->emp_status;
    	$insert->emp_company = $request->emp_company;
    	$insert->emp_experience = $request->emp_experience;
    	$insert->emp_resume = $request->emp_resume;
    	$insert->emp_department = $request->emp_department;
    	$insert->emp_image = $name;
    	$insert->company_mail = $request->company_mail;
    	$insert->emp_id = $request->emp_id;
    	$insert->emp_password = $request->emp_password;

        if($insert->save())
        {
            $request->session()->flash('alert-success', 'Employee Added Successfully!');
            return redirect('show_employee_list');
            //return $request->all();
        }
        else
        {
            echo "Error";
        }

        /*Employee History Table*/

        $insert1 = new Employeehistory;

        /*$insert->validate($request, [
        'emp_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',]);*/
        if ($request->hasFile('emp_image')) {
        $image = $request->file('emp_image');
        $name = time().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('emp_images');
        $image->move($destinationPath, $name);
        /*$insert->save();*/

        //return back()->with('success','Image Upload successfully');
        }
        $insert1->emp_fname = $request->emp_fname;
        $insert1->emp_lname = $request->emp_lname;
        $insert1->emp_dob = $request->emp_dob;
        $insert1->emp_age = $request->emp_age;
        $insert1->emp_mail = $request->emp_mail;
        $insert1->emp_number1 = $request->emp_number1;
        $insert1->emp_number2 = $request->emp_number2;
        $insert1->emp_doj = $request->emp_doj;
        $insert1->emp_address = $request->emp_address;
        $insert1->emp_status = $request->emp_status;
        $insert1->emp_company = $request->emp_company;
        $insert1->emp_experience = $request->emp_experience;
        $insert1->emp_resume = $request->emp_resume;
        $insert1->emp_department = $request->emp_department;
        $insert1->emp_image = $name;
        $insert1->company_mail = $request->company_mail;
        $insert1->emp_id = $request->emp_id;
        $insert1->emp_password = $request->emp_password;


    	if($insert1->save())
    	{
    		$request->session()->flash('alert-success', 'Employee Added Successfully!');
            return redirect('show_employee_list');
            //return $request->all();
    	}
    	else
    	{
    		echo "Error";
    	}
    }

    /*Edit a Particular Details*/
    public function employee_edit($id)
    {
        $value['value'] = Addemployee::find($id);
        $value['department'] = Department::all();
        return view('employee_edit', $value);
    }
    
    /*Update a Particular Details*/
    public function update_employee(Request $request)
    {
        $update = Addemployee::find($request->id);
        $update->emp_fname = $request->emp_fname;
        $update->emp_lname = $request->emp_lname;
        $update->emp_dob = $request->emp_dob;
        $update->emp_age = $request->emp_age;
        $update->emp_mail = $request->emp_mail;
        $update->emp_number1 = $request->emp_number1;
        $update->emp_address = $request->emp_address;
        $update->emp_department = $request->emp_department;
        //$update->emp_image = $request->emp_image;
        $update->emp_password = $request->emp_password;

        if($update->save())
        {
            $request->session()->flash('alert-success', 'Employee Updated Successfully!');
            return redirect('show_employee_list');
            //return $request->all();
        }
        else
        {
            echo "Error";
        }
    }

    /*Show Employee History*/
    public function show_employee_history()
    {
        $value1['value1'] = Employeehistory::all();
        return view('employee_history', $value1);
    }

    /*Delete a Particular Details*/
    public function delete_employee($id)
    {
        $value = Addemployee::find($id);
        $result = ($value->delete());
        if(!$result)
        {
            echo "Error";
        }
        else
        {
            return redirect('show_employee_list');
        }
    }
}
