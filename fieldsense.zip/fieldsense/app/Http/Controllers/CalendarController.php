<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Calendar;

class CalendarController extends Controller
{

	public function events()
	{
    	//return view('event_calendar');  
    	$tasks['tasks'] = Calendar::all();
       	return view('event_calendar', $tasks);
    }

    public function show_event()
    {
    	$tasks['tasks'] = Calendar::all();
       	return view('event_calendar', $tasks);
    }

    public function save(Request $request)
    {
    	$val = new Calendar;
    	$val->event_name = $request->event_name;
    	$val->event_description = $request->event_description;
    	$val->start_date = $request->start_date;
    	
    	$result = $val->save();
    	if (!$result) {
    		echo "Error"; 
    	}
    	else
    	{
            return redirect('events');
            //echo "Success";

    	} 
    }
}
