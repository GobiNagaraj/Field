<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Department;

class DepartmentController extends Controller
{
    public function index(){
    	return view('add_department');
    }
    public function save(Request $request){
    	$insert = new Department;
    	$insert -> department = $request -> department;
    	$insert -> team = $request -> team;
    	$insert -> team_leader = $request -> team_leader;

    	if($insert -> save())
    	{
    		$request->session()->flash('alert-success', 'Department Added Successfully!');
			return redirect('add_department');
    	}
    	else
    	{
    		echo "Error";
    	}
    }
}
