
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keyword" content="Edcloud, GPS, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet prefetch" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet prefetch" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="<?php echo e(URL::asset('/images/title.png')); ?>" type="image/png">

    <title>Ed Cloud Solution</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('css/bootstrap-reset.css')); ?>" rel="stylesheet">
    <!--external css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/design-home.css')); ?>">
    <link href="<?php echo e(URL::asset('assets/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css')); ?>" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/owl.carousel.css')); ?>" type="text/css">

    <!--right slidebar-->
    <link href="<?php echo e(URL::asset('css/slidebars.css')); ?>" rel="stylesheet">

    <!-- Custom styles for this template -->

    <link href="<?php echo e(URL::asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('css/style-responsive.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/calendar.css')); ?>">
  </head><!DOCTYPE html>