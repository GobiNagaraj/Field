<?php $__env->startSection('content'); ?>

<body>

<div class="login_form">
  <setion class="login-wrapper">
    
    <form id="login" method="post" action="#">
      <header class="login-form__header">
          <img src="<?php echo e(URL::asset('/images/ed.jpg')); ?>" alt="Edcloud Solution"  />
          <br />
    </header>
      <label for="username">User Name</label>
      <input  required name="login[username]" type="text" autocapitalize="off" autocorrect="off"/>

      <label for="password">Password</label>
      <input class="password" required name="login[password]" type="password" />
      <div class="hide-show">
        <span>Show</span>
      </div>
      <button type="submit">Sign In</button>
    </form>
    
  </section>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
</body>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>