<style type="text/css">
	body
	{
		background-image: url(/images/laptop.png);
		background-repeat: no-repeat;
		background-size: cover;
	}
	.center
	{
		text-align: center;
	}
	.logo img
	{
		height: 100px;
		margin: 10px auto;
	}
	.row
	{
		margin: 50px auto;
	}
	.row img
	{
		width: 150px;
		height: 150px;
	}
	label
	{
		color: red;
	}
	.temp
	{
		margin: 280px 0;
	}
</style>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="center">
			<div class="logo">
				<img src="<?php echo e(URL::asset('/images/edpng.jpg')); ?>" alt="EdCloud Solution">		
			</div>
	</div>
	<div class="temp">
		<div class="row">
			<div class="col-md-2 col-md-offset-1">
				<a href="/admin" target="_blank"><img src="<?php echo e(URL::asset('/images/admin.gif')); ?>" alt="Admin"><p class="col-md-offset-2"><label>Admin Login</label></p></a>
			</div>
			<div class="col-md-2 col-md-offset-1">
				<a href="/employee" target="_blank"><img src="<?php echo e(URL::asset('/images/employee.png')); ?>" alt="Employee"><p class="col-md-offset-2"><label>Employee Login</label></p></a>
			</div>
			<div class="col-md-2 col-md-offset-1">
				<a href="/sales" target="_blank"><img src="<?php echo e(URL::asset('/images/salman.png')); ?>" alt="Sales" id="sales"><p class="col-md-offset-2"><label>Sales Login</label></p></a>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>