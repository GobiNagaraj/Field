<?php $__env->startSection('content'); ?>

<body>

<div class="login_form">
  <setion class="login-wrapper">
    <form id="login" method="post" action="/hr_login">
      <header class="login-form__header">
          <img src="<?php echo e(URL::asset('/images/ed.jpg')); ?>" alt="Edcloud Solution"  />
          <br />
    </header>
    <?php echo e(csrf_field()); ?>

      <label for="username">User Name</label>
      <input name="login[username]" type="text" autocapitalize="off" autocorrect="off"/>

      <label for="password">Password</label>
      <input class="password" name="login[password]" type="password" />
      <div class="hide-show">
        <span>Show</span>
      </div>
      <button type="submit">Sign In</button>
      <a href="#" class="login-form__forgot-password col-lg-5"> Forgot your password?
          </a>
    </form>
    
  </section>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
</body>
<!-- <div class="perspective-container">
    <div class="login-card">
      <form action="/hr_login" method="POST" class="login-form login-form_sing-in">
        <header class="login-form__header">
          <img src="<?php echo e(URL::asset('/images/ed.jpg')); ?>" alt="Edcloud Solution"  />
          <br />
        </header>
        <?php echo e(csrf_field()); ?>

        <div class="login-form__inputs-container">
        	<input type="email" name="usermail" placeholder="Enter Mail" class="login-form__input login-form__input_required" >
        	<input type="password" name="userpass" placeholder="Enter Password" class="login-form__input login-form__input_required" >
          <a href="#" class="login-form__forgot-password"> Forgot your password?
          </a>
        </div>

        <footer class="login-form__footer">
          <button type="submit" class="login-form__submit"> Login
          </button>
          <div class="checkbox__title"> Need an account? <a href="#" class="login-form__toggle">Sing Up</a>
          </div>
        </footer>
      </form>
    </div>
  </div> -->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>