<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>EdCloud Solution</title>
	<link rel="icon" href="<?php echo e(URL::asset('/images/title.png')); ?>" type="image/png">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/bootstrap/css/bootstrap.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('/bootstrap/css/bootstrap.min.css')); ?>">
	
	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script type="text/javascript" src="<?php echo e(URL::asset('/bootstrap/js/bootstrap.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('/bootstrap/js/bootstrap.min.js')); ?>"></script>
</head>
<body>
	<?php echo $__env->yieldContent('content'); ?>
</body>
</html>